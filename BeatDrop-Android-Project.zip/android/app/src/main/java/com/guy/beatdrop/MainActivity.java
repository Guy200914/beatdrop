package com.guy.beatdrop;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
